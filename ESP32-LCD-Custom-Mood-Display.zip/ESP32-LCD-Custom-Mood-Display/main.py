from machine import Pin, I2C
from i2c_lcd import I2cLcd

# I2C LCD setup
i2c = I2C(0, scl=Pin(22), sda=Pin(21))
lcd = I2cLcd(i2c, 0x27, 2, 16)

# Custom heart character
heart = bytearray([0, 10, 31, 31, 31, 14, 4, 0])

# Custom smiley character
smile = bytearray([0, 10, 10, 0, 17, 14, 0, 0])

# Custom sad-face character
sad = bytearray([0, 10, 10, 0, 14, 17, 0, 0])

# Register custom characters
lcd.custom_char(0, heart)
lcd.custom_char(1, smile)
lcd.custom_char(2, sad)

# Display mood symbols
lcd.clear()
lcd.putstr("Mood: ")
lcd.putchar(chr(0))  # Heart
lcd.putchar(chr(1))  # Smiley
lcd.putchar(chr(0))  # Heart, matching the supplied code
