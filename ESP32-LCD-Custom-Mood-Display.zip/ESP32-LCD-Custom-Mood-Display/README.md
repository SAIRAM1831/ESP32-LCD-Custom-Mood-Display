# ESP32 LCD Custom Mood Display

A MicroPython project using an ESP32 and a 16×2 I2C LCD to display custom characters, including a heart and facial expressions.

## Features
- Creates custom LCD characters from 8-byte bitmap patterns
- Registers characters in the LCD's custom character memory
- Displays a mood label and symbols on the screen

## Hardware
- ESP32 development board
- 16×2 LCD with I2C backpack
- Jumper wires

## Pin Connections

| LCD connection | ESP32 GPIO |
|---|---:|
| SDA | GPIO 21 |
| SCL | GPIO 22 |

The sample code uses I2C address `0x27`; your LCD may use a different address.

## Files
- `main.py` — MicroPython program
- `images/project-photo.jpg` — photo of the working hardware
- `i2c_lcd.py` — required LCD driver (not included)

## Setup
1. Install MicroPython on the ESP32.
2. Copy a compatible `i2c_lcd.py` driver to the ESP32.
3. Save `main.py` to the ESP32 using Thonny or another MicroPython tool.
4. Confirm the LCD address and wiring.
5. Run or reset the ESP32.

## Expected Output
The LCD displays `Mood:` followed by the custom characters registered in the program. The code registers a sad-face character as ID 2 but does not display it; the final symbol is a heart, matching the supplied code.

## Project Photo
See [`images/project-photo.jpg`](images/project-photo.jpg).

## Note
This is an educational project. The LCD driver must support the `custom_char()` method.
